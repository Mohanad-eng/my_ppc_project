// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interface:srv/MissionService.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACE__SRV__DETAIL__MISSION_SERVICE__STRUCT_H_
#define ROBOT_INTERFACE__SRV__DETAIL__MISSION_SERVICE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'mission_name'
#include "rosidl_runtime_c/string.h"

// Struct defined in srv/MissionService in the package robot_interface.
typedef struct robot_interface__srv__MissionService_Request
{
  rosidl_runtime_c__String mission_name;
} robot_interface__srv__MissionService_Request;

// Struct for a sequence of robot_interface__srv__MissionService_Request.
typedef struct robot_interface__srv__MissionService_Request__Sequence
{
  robot_interface__srv__MissionService_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interface__srv__MissionService_Request__Sequence;


// Constants defined in the message

// Struct defined in srv/MissionService in the package robot_interface.
typedef struct robot_interface__srv__MissionService_Response
{
  bool accepted;
} robot_interface__srv__MissionService_Response;

// Struct for a sequence of robot_interface__srv__MissionService_Response.
typedef struct robot_interface__srv__MissionService_Response__Sequence
{
  robot_interface__srv__MissionService_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interface__srv__MissionService_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACE__SRV__DETAIL__MISSION_SERVICE__STRUCT_H_
