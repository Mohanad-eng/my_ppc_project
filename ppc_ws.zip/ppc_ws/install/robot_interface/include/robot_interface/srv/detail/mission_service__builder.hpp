// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interface:srv/MissionService.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACE__SRV__DETAIL__MISSION_SERVICE__BUILDER_HPP_
#define ROBOT_INTERFACE__SRV__DETAIL__MISSION_SERVICE__BUILDER_HPP_

#include "robot_interface/srv/detail/mission_service__struct.hpp"
#include <rosidl_runtime_cpp/message_initialization.hpp>
#include <algorithm>
#include <utility>


namespace robot_interface
{

namespace srv
{

namespace builder
{

class Init_MissionService_Request_mission_name
{
public:
  Init_MissionService_Request_mission_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_interface::srv::MissionService_Request mission_name(::robot_interface::srv::MissionService_Request::_mission_name_type arg)
  {
    msg_.mission_name = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interface::srv::MissionService_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interface::srv::MissionService_Request>()
{
  return robot_interface::srv::builder::Init_MissionService_Request_mission_name();
}

}  // namespace robot_interface


namespace robot_interface
{

namespace srv
{

namespace builder
{

class Init_MissionService_Response_accepted
{
public:
  Init_MissionService_Response_accepted()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_interface::srv::MissionService_Response accepted(::robot_interface::srv::MissionService_Response::_accepted_type arg)
  {
    msg_.accepted = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interface::srv::MissionService_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interface::srv::MissionService_Response>()
{
  return robot_interface::srv::builder::Init_MissionService_Response_accepted();
}

}  // namespace robot_interface

#endif  // ROBOT_INTERFACE__SRV__DETAIL__MISSION_SERVICE__BUILDER_HPP_
