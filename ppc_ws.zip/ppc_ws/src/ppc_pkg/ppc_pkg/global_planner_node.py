#!/usr/bin/env python3

import rclpy 
import sys 
from rclpy.node import Node
from turtlesim.msg import Pose
from std_msgs.msg import String
from geometry_msgs.msg import Pose
from std_srvs.srv import Trigger
from nav_msgs.msg import Path
from robot_interface.srv import MissionService


class GlobalplannerNode(Node):
    def __init__(self):
        super().__init__("Global_planner_node")
        self.srv = self.create_service(Trigger, '/create_plan', self.create_plan_callback)


    def create_plan_callback(self,request,response):
        current_pose = Pose()
        current_pose.position.x = 0
        current_pose.position.y = 0

        


        
    




def main():
    rclpy.init()
    node = GlobalplannerNode()

    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()