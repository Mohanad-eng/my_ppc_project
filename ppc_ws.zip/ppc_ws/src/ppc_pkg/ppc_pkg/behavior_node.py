#!/usr/bin/env python3

import rclpy 
import sys 
from rclpy.node import Node
from turtlesim.msg import Pose
from std_msgs.msg import String

class MybehaviorNode(Node):
    def __init__(self):
        super().__init__("behavior_node")
        self.state = "idle"
        self.publish_state= self.create_publisher(String,"/state",10)
        self.subscriber= self.create_subscription(String,"/mission",self.callback_state,10)


    def callback_state(self,msg:String):
        if msg.data == "GoTo":
            self.get_logger().info("working")
            self.publish_state_update()
            #self.create_plan_service()
            self.state = "navigate"
            self.get_logger().info(f"state {self.state}")
        elif msg.data == "Stop":
            self.state = "idle"
            self.publish_state_update()
            self.get_logger().info(f"state {self.state}")
        else:
           self.get_logger().warning(f"Unrecognized command: {msg.data}")

    def publish_state_update(self):
        state_msg = String()
        state_msg.data = self.state
        self.publish_state.publish(state_msg)


def main(args=None):
    rclpy.init(args=args)

    node = MybehaviorNode()

 
    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()