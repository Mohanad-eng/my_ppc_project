#!/usr/bin/env python3

import rclpy 
import sys 
from rclpy.node import Node
from turtlesim.msg import Pose
from std_msgs.msg import String
from robot_interface.srv import MissionService


class Mymissionnode(Node):
    def __init__(self):
        super().__init__("mission_node_1")
        self.srv = self.create_service(MissionService,"/start_mission",self.start_mission_callback)
        self.publisher_1 = self.create_publisher(String,"/mission",10)
        self.cli = self.create_client(MissionService, "/start_mission")
        while not self.cli.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('service not available, waiting again...')
        self.req = MissionService.Request()

    def start_mission_callback(self,request,response):
        if request.mission_name in ["GoTo","Stop"]:
            response.accepted = True
            msg = String()
            msg.data = request.mission_name
            self.publisher_1.publish(msg)
        else :
            response.accepted = False
            
        
        return response
    
    def send_request(self, mission_name ):
        self.req.mission_name = mission_name
        self.future = self.cli.call_async(self.req)
        rclpy.spin_until_future_complete(self, self.future)
        return self.future.result()
    







def main(args=None):
    rclpy.init(args=args)

    node = Mymissionnode()
    response = node.send_request(str(sys.argv[1]))
    node.get_logger().info(f"mission is {str(sys.argv[1])}")
    node.get_logger().info(f"mission is {response.accepted}")

    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()