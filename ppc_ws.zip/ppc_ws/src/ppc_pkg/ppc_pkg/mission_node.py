#!/usr/bin/env python3

import rclpy 
from rclpy.node import Node
from turtlesim.msg import Pose
from std_msgs.msg import String
from robot_interface.srv import MissionService


class Mymissionnode(Node):
    def __init__(self):
        super().__init__("mission_node")
        self.srv = self.create_service(MissionService,"/start mission",self.start_mission_callback)
        self.publisher_1 = self.create_publisher(String,"/mission",10)
    def start_mission_callback(self,request,response):
        if request.mission_name in ["GoTo","Stop"]:
            response.accepted = True
            self.publisher_1.publish(str(data=request.mission_name))
        else :
            response.accepted = False
        return response 







def main(args=None):
    rclpy.init(args=args)

    node = Mymissionnode()

    rclpy.spin(node)
    rclpy.shutdown()


if __name__ == '__main__':
    main()